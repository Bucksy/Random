<?php

//include './tasks/form.php';

?>
<table>
<!--        <tr>
           <td>ID :</td>
           <td><input type="text" name="id" value="<?php // echo isset($data['id']) ? $data['id'] : ''  ?>" /></td>
       </tr>-->
    <tr>
        <td>Name: </td>
        <td><input type="text" name="name" id="title"/></td>
    </tr>
    <tr>
        <td>Description: </td>
        <td><textarea name="description" id="desc"></textarea></td>
    </tr>
    <tr>
        <td>Priority: </td>
        <td>
            <select name="priority" id="priority">
                <option value="1">Low</option>
                <option value="2">Medium</option>
                <option value="3">High</option>
            </select>
        </td>
    </tr>
    <tr>
        <td>Created Date: </td>
        <td><input type="text" name="created" id="created"/></td>
    </tr>
    <tr>
        <td>Due Date: </td>
        <td><input type="text" name="dueDate" id="dueDate" /></td>
    </tr>
    <tr>
        <td colspan="2" ><input type="submit" name="createPost" value="Create"  class="create"/></td>
    </tr>
</table>
<div id="response">
    
</div>
<script>
    $(document).ready(function(){
         //alert(1);
        $('body').on('click', '.create', function(){
            //alert(1);
            createTask();
        })
        
       function createTask(){
           var name = $('table tr #title');
           var desc = $('table tr #desc');
         //  var priority = $('table tr priority');
          // alert(priority);
           $.ajax({
               url: 'tasks/createAjax.php',
               method: 'POST',
               data: {
                   name: $(name).val(),
                   description: $(desc).val()
               },
               dataType: 'json'
           }).done(function(response){
               for(i in response){
                   $('#response').append('<p class="blue"> You have created a task : ' + response[i].name + ' with a description : '+ response[i].description +'</p>');
               }
           }).fail(function(jqXHR, textStatus){
               alert('Failed Request: ' + textStatus);
           });
       }
    })
</script>
