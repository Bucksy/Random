<?php

header('Content-Type: application/json');
$response[] = array(
    'name'=> $_POST['name'],
    'description'=> $_POST['description']
);

echo json_encode($response);
