<?php

//VIEW - tasks = array(); or 
function init(){
$tasks = array(
    0=>array(
        'id'=>'1',
        'name'=> 'Task 1',
        'description'=> 'Description for Task 1',
        'priority'=>'High',
        'created'=> '2015-01-20 17:00',
        'dueDate'=> '2015-01-20 05:00' // date($timeFormat, mktime(22, 0, 0, 1, 20, 2015)),// date($timeFormat , strtotime(+1 day));
    ),
     1=>array(
        'id'=>'2',
        'name'=> 'Task 2',
        'description'=> 'Description for Task 2',
        'priority'=>'Low',
        'created'=>'2015-01-19 12:00',
        'dueDate'=>'2015-01-20 09:00'
    ),
     2=>array(
        'id'=>'3',
        'name'=> 'Task 3',
        'description'=> 'Description for Task 3',
        'priority'=>'Medium',
        'created'=>'2015-01-15 12:07',
        'dueDate'=>'2015-01-20 15:00'
    ),
);
writeTasks($tasks);
}

//init();

function listTasks(){ //return Tasks Array
    if (!isset($_SESSION['logged'])) {
        redirectToDefaultPage('user', 'login');
    }
    $id = $_SESSION['user_id'];
   $connection = dbConnect(); //vrushta resource - obekt . znae kak da se svurje s mysql ili failova sistema
  
   $query = "SELECT * FROM tasks WHERE userid = $id";
   //exit(var_dump($result));
   $result = mysql_query($query, $connection);//prashtame zaqvka kum mysql, vrushta resource
   //exit(var_dump($result));
    if (!$result){
        echo 'error';
    }
    
    while($task = mysql_fetch_object($result)){
        //exit(print_r($tasks, true));
       $tasks[] = $task; //array of objects
    }
   
    mysql_close($connection);
    //exit('<pre>' . print_r($tasks, true) . '</pre>');
    return $tasks;//masiv ot objects
  //  exit(var_dump($tasks));
}

function createTasks() {
   
    if (!isset($_SESSION['logged'])) {
        redirectToDefaultPage('user', 'login');
    }
   //vrushta resource - obekt . znae kak da se svurje s mysql ili failova sistema
   //we check if this a POst request
   if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
      return;
   }else{
        $connection = dbConnect();
//        
//       $name = trim($_POST['name']);
//       $description = trim($_POST['description']);
//       $priority = (int)$_POST['priority'];
//       $createdDate = trim($_POST['created']);
//       $dueDate = trim($_POST['dueDate']);
        //echo '<pre>' . print_r($_POST, true) . '</pre>';
        
       //Validation //TODO 
       //Dannite veche sa v bazata , taka nqmame nujda da izvikvame listTasks();
       
//       $sql = mysql_query('INSERT INTO tasks(name, description, priority, dueDate)
////                           VALUES("'.$name.'", "'.$description.'", '.$priority.',"'.$dueDate.'")',$connection);
//     
        
       $task = fetchPostData();
       $query = sprintf('INSERT INTO tasks(name, description, priority, dueDate, userid)
                VALUES("%s", "%s", "%s", "%s", "%s")', 
                       $task['name'],$task['description'], $task['priority'], $task['dueDate'], $_SESSION['user_id']);
       
       //$query = 'INSERT INTO tasks (name, description, priority, dueDate, userid) VALUES ("'.$name.'","'.$description.'", "'.$priority.'", "'.$dueDate.'", "'.$_SESSION['user_id'].'")';
       $sql =  mysql_query($query, $connection);
       if (!$sql) {
           echo mysql_error($connection);
           exit;
       }

       mysql_close();
       redirectToDefaultPage();
   }
}

function dbConnect(){
     
     $connection =  mysql_connect('localhost', 'root', '') or die ('Error '); //vrushta resource - obekt . znae kak da se svurje s mysql ili failova sistema
     mysql_set_charset('utf8');
     $db = mysql_select_db('todo', $connection) or die('Error in database'); //Select database
     return $connection;

}

function updateTasks() {
    if (!isset($_SESSION['logged'])) {
        redirectToDefaultPage('user', 'login');
    }
   
    if (empty($_GET['id'])) {
        $idGet = '';
    }
    
    $idGet = $_GET['id'];
    
    $connection = dbConnect();
    
    if($_SERVER['REQUEST_METHOD'] === 'GET') { //GET
       
        $selected = 'SELECT id, name, description, priority , created, dueDate FROM tasks WHERE id = ' . $idGet . '';
        $query = mysql_query($selected, $connection); //return id of query 
        
        $task = mysql_fetch_object($query);
        mysql_close($connection); // tuka trqbva zatvorim koda tui kato pri return nie izlizame ot funkciqta i ne vlizame v else if otdolu
        return $task;
        
    }else if ($_SERVER['REQUEST_METHOD'] === 'POST') {
   
        $name = trim($_POST['name']);
        $description = trim($_POST['description']);
        $priority = (int) $_POST['priority'];
        $dueDate = trim($_POST['dueDate']);
        $sql = mysql_query('UPDATE tasks 
                            SET name = "' . $name . '", description = "' . $description . '", priority = ' . $priority . ', dueDate = "' . $dueDate . '"
                            WHERE id = '.$idGet, $connection);
        if (!$sql) {
            echo 'Error';
        } else {
            mysql_close($connection);
            redirectToDefaultPage();
        }
        
//        $task = fetchPostData();
//       
//        $sql = sprintf('UPDATE tasks SET name = "%s", description = "%s", priority = "%s", dueDate = "%s" 
//                       WHERE id = %s', $task['name'], $task['description'], $task['priority'], $task['dueDate'] );
//      
//       mysql_query($sql, $connection);
//       mysql_close($connection);
//       redirectToDefaultPage();
    }
}

function deleteTasks() {

    $connection = dbConnect();
    if (empty($_GET['id'])) {
        $_GET['id'] = '';
    }
    $idGet = $_GET['id'];

    $sql = mysql_query('DELETE FROM tasks WHERE id = ' . $idGet . '', $connection);
    mysql_close($connection);

    redirectToDefaultPage();
}

function registerUser() {
    $connection = dbConnect();
    if (isset($_POST['login'])){
        if (!empty($_POST['username']) && !empty($_POST['password'])) {
            $username = trim($_POST['username']);
            $password = $_POST['password'];

            $username = mysql_real_escape_string($username);
            $password = mysql_real_escape_string($password);

            $password = md5($password);

            //TODO - validation data
    
            $query = mysql_query('SELECT * FROM user WHERE username = "' . $username . '"', $connection);


            if (!$query) {
                echo mysql_error($connection);
            } else {
                echo 'Ok';
            }

            $num_rows = mysql_num_rows($query);
            //echo $num_rows;//1
            if (mysql_num_rows($query) == 1) {
                echo 'The username already exists!. Please try again with another!';
            } else {
                $query = 'INSERT INTO user (username, password) VALUES ("' . $username . '", "' . $password . '")';
                $sql = mysql_query($query, $connection);
                if (!$sql) {
                    echo mysql_error($connection);
                } else {
                    header('Location: index.php');
                }
            }
        }else {
            echo '<p class="error">Invalid username or password</p>';
        }
    }
     mysql_close($connection);
}

//Иначе за тези, които не бяха миналия път - довършихме и останалите функции (create, update, delete), да работят с данните от базата.
//
//За домашно:
//- Създаване на форма за логин на потребител с полета за username и password; - done 
//- Създаване на таблица 'user' в базата със съответните полета, отговарящи на формата (и каквито други прецените, че е нужно да се направят); -Processing
//- Всеки да си въведе по един потребител с парола в таблицата user;
//- Създаване на функция, която да намира даден потребител в базата, по неговото потребителско име и парола

//For Niki - Tutorial 

//function loginTasks(){
//    
//     if (empty($_POST)) {
//        return;
//    }
//    
//    $connection = dbConnect();
//
//    $username = trim($_POST['username']);
//    $password = $_POST['password'];
//
//    $username = mysql_escape_string($username);
//    $password = mysql_escape_string($password);
//
//    $query = 'SELECT * FROM user WHERE username = "' . $username . '" AND password = "' . $password . '"';
//    
//    $sql = mysql_query($query, $connection);
//    
//    if (mysql_num_rows($sql) == 1) {
//        echo 'Hello ' .$username. '!!!!!';
//    }else{
//        echo 'Invalid username or password';
//    }
//     mysql_close($connection);
//}

 //With Sessions 
function loginUser(){
    if (isset($_SESSION['logged'])) {
        //header('Location: index.php?page=tasks');
        redirectToDefaultPage();
    }
    //else check below
    if (empty($_POST)) {
        return;
    }
    
    $connection = dbConnect();

    $username = $_POST['username'];
    $password = $_POST['password'];
     
    $username = mysql_escape_string($username);
    $password = mysql_escape_string($password);
    
    $password = md5($password);
    
    $sql = mysql_query('SELECT id FROM user WHERE username = "' . $username . '" AND password = "' . $password . '"', $connection);
    //$row = mysql_fetch_assoc($sql);
    //echo '<pre>' . print_r($row, true) . '</pre>';
    // exit(var_dump($$row['user_id']));
    //$sql = mysql_query($query, $connection);
    
    //exit(var_dump($row['id']));
    if(mysql_num_rows($sql) == 1) {
        
        $row = mysql_fetch_assoc($sql);
        $_SESSION['logged'] = true;
        $_SESSION['username'] = $username;
        $_SESSION['user_id'] = $row['id'];
        redirectToDefaultPage();
    }else {
       echo '<p style="color:red;">Invalid username or password!!!!!!!</p>';
    }
    
    mysql_close($connection);
}

function logoutUser(){
    session_start();
    session_destroy();
    header('Location: index.php');
    exit;
}

function writeTasks($tasks){
   $json = json_encode($tasks);//CONVERT array tasks INTO JSON and put it in the file
   file_put_contents('./data/tasks.json', $json);
}

function fetchPostData() { // VAlidation ? 
    return array(
            'id' => $_POST['id'], //TODO Generate sequent ID
            'name' => $_POST['name'],
            'description' => $_POST['description'],
            'priority' => $_POST['priority'],
            'created' => $_POST['created'],
            'dueDate' => $_POST['dueDate'],
        );
}

function redirectToDefaultPage($page = 'tasks', $action = 'list'){
     header("Location: index.php?page=$page&action=$action");
     exit;
}

function toggle() {
    if (isset($_GET['order'])) {
        return $_GET['order'] == 0 ? 1 : 0;
//          return (int)!$_GET['order'];, poneje ni vrushta kato bool(false) ili bool(true)
    }
    return 1; 
}

//Sort all fields in array tasks
function sortAll(&$tasks, $order) {
    if (isset($_GET['field']) && isset($_GET['order'])){
        if ($order == 0) {
            uasort($tasks, function ($a, $b) {
               return strcmp($a->$_GET['field'] ,$b->$_GET['field']);//0 - 1, 1 
                    });
        } else{
            uasort($tasks, function($a, $b) {
                        return strcmp($b->$_GET['field'] ,$a->$_GET['field']);
                    });
        }
    }
}

//step over - ako e funkciq - izpulnqva se funkciq , step over - vliza na vseki red - F8
//continue - videli sme kakvoto ni trqbva, i prosto minavame natatuk

function proccessRequest(){
    if (isset($_GET['page'])) { //http://localhost/todo/functions.php?page=tasks
        $defaultAction = 'list';// 
        $page = $_GET['page']; // $page=tasks
        
        echo "Page: . $page<br/>" ;
        
        if (isset($_GET['action'])) { //http://localhost/todo/functions.php?page=tasks&action=list
            $action = $_GET['action']; // action = list
            //trqbva da zaredim dannite s listTask();
            echo "Action : $action";
            
           $function = $action. ucfirst($page);//list.Tasks() = function listTasks(); = $data = masiv s taskovete otgore
           echo '<br/>';
           echo "Function name: $function ()<br/>";
            
           $includeFile =  "$page/$action"; //tasks/list
            //include "./$includeFIle.php";
        }else{
             $function = $defaultAction . ucfirst($page);//listTasks
             echo "Function name:  $function()<br/>";
             $includeFile = "$page/$defaultAction"; // tasks / action = list , ako nqmame tasks a samo action - nqma da raboti, tui kato ne sme proverili za tozi sluchai
        }
       
        $data = $function();//listTasks(); - return array of tasks 
          
        echo "Include File: $includeFile.php<br/>";//Include File: tasks/list.php
        include "./$includeFile.php";//list.php;
    }
}


function getAllParams(){
    if(isset($_GET['action'])){
       return "page=".$_GET['page']. "&" ."action=". $_GET['action'];
    }
    return "page=".$_GET['page'];
}


//function mysqlTest(){
//    // Open a connection to a MySQL Server
//   $connection =  mysql_connect('localhost', 'root', '') or die('Error while connening to the database'); //vrushta resource - obekt . znae kak da se svurje s mysql ili failova sistema
//   //var_dump($connection);  
//   if (!$connection) {
//       echo 'Error while connecting to the database';
//       exit;
//   }else{
//       echo 'Success';
//   }
//   
//   //Select database - resource
//   $db = mysql_select_db('todo', $connection);
//   if (!$db) {
//       echo 'Failed to select to DB';
//       exit;
//   }else{
//       echo 'Success';
//   }
//   //Query
//   
//   $query = 'SELECT * FROM tasks';
//   $result = mysql_query($query, $connection);//prashtame zaqvka kum mysql, vrushta resource
//    if (!$result) {
//        echo 'error';
//    } else {
//        echo 'ok';
//    }
//    
//   echo 'Number of rows : ' . mysql_num_rows($result), '<br/>';//number of rows
//   echo 'Number of fields : ' .  mysql_num_fields($result);//number of columns
//   
//   while ($row = mysql_fetch_assoc($result)) {
//       echo '<pre>' . print_r($row['name'], true) . '</pre>';
//   }
//   
////   print_r(mysql_fetch_array($result));
////    var_dump(mysql_fetch_array($result));
////    $m = mysql_result($result, 3, 1);
////    echo $m;
//   
//    mysql_close($connection);
//}
//
//mysqlTest();

