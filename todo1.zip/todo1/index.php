<?php
session_start();
$title = 'Tasks List';
include './data.php';
include './functions.php';
include './inc/header.php';

?>
<!--<script type="text/javascript" src="js/main.js"></script>-->
<body class="home" onload="startTime();">
        <div class="container">
            <div class="top">
                <div class="logo">
                    <a href="index.php">
                       <!-- <img class="logo1"src="img/logo.jpg"></img> -->
                    </a>
                </div>
                <div class="date" id="txt">
                <?//=date('Y-m-d H:i:s', time() + 3600); ?>
                </div>
                <div class="menu">
                    <ul id="demo"><?php
                        foreach ($menu as $value) {
                            echo '<li><a href="'. $value['link'] .'">'. $value['name'] .'</a></li>';
                        }
                        ?></ul> 
                    <div class="greeting">
                        <?php if (isset($_SESSION['logged'])) : ?>
                            <?php echo 'Hello ' . $_SESSION['username'] . '!' . '<a href="index.php?page=user&action=logout">Log out</a>'; ?>
                        <?php else : ?>
                            <a href="index.php?page=user&action=register">Register</a>
                            <form method="POST" action="index.php?page=user&action=login">
                                <label id="username">Username: </label>
                                <input type="text" name="username" id="username" class="textField"/><br/>
                                <label id="password">Password: </label>
                                <input type="password" name="password" id="password" class="textField"/><br/>
                                <input type="submit" name="login" value="Log in" id="loginBut"/>
                            </form>
                        <?php endif;?>
                    </div>
                </div>
            </div>
            <div class="body">
                <?php proccessRequest();// shows the table from list.php ?>
            </div>
        </div>
    
<!--    <script>
      var li = document.createElement('li');
      var text = document.createTextNode('List Item');
      li.appendChild(text);
      var element = document.getElementByTagName('UL');
      element.appendChild(li);
    </script>-->
    
    <script type="text/javascript" src="js/main.js"></script>
<?php 
include './inc/footer.php';
?>

