//1.Добавете нов item от менюто чрез javascript;

var ul = document.getElementById('demo');//Get the Unordered List with id = list 
var li = document.createElement('li');// Create a new list item
var text = document.createTextNode('New List Item'); //Create a text
li.appendChild(text);//Append the text to the list item 
ul.appendChild(li); //Append the new list item to the ul

//2. Премахнете първия елемент от менюто с javasript;

//console.log(ul);
if(ul.hasChildNodes()){
    //console.log(ul.childNodes[0]);
    //console.log(ul.childElementCount);
    ul.removeChild(ul.childNodes[3]);//return the first deleted child <li>
   //be careful with the whitespaces -> because they return textNodes();
}

//Променете стилът на някой от елементите в менюто (да кажем направете някой от линковете болднат и с друг цвят);
ul.childNodes[1].style.backgroundColor = 'red';
ul.childNodes[0].style.fontSize =  "xx-large";