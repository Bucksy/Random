<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title><?=$title;?></title>
        <link rel="stylesheet" type="text/css" href="css/styles.css"/>
        <script type="text/javascript" src="./js/clock.js"></script>
        <script type="text/javascript" src="./js/jquery-1.11.2.min.js"></script>
    </head>