<form method="POST" action="index.php?page=user&action=login">
    <label id="username">Username: </label>
    <input type="text" name="username" id="username" class="textField"/><br/>
    <label id="password">Password: </label>
    <input type="password" name="password" id="password" class="textField"/><br/>
    <input type="submit" name="login" value="Log in" id="loginBut"/>
</form>